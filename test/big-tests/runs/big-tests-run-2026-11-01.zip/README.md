# GenomicSQLite big-tests run record

This is a sanitized record of the full big-tests workflow on a single
c7gd.4xlarge (16 Arm64 vCPUs, 32 GiB RAM, 950 GB NVMe instance store), in
us-west-2. The workflow started at 2026-11-01 18:41:20 UTC and completed at
22:53:12 UTC (08:41–12:53 Hawaii time), exit status 0.

The WDL revision is `cd9f36b1da2cc8a2934878cd598330a2069faf53`.
The workflow's `git_revision` input was `main`; the source actually built was
`dc55544fc0bfd1148b8265cd495799b9e22cb616`. Thus the WDL revision and the
source revision are distinct. The workflow and task logs record input URLs,
commands, results, build output and timings. Public datasets are identified by
their original URLs; data and generated databases are not included.

All six CTest tests passed, including pytest (40 passed, one amd64-specific
skip); `test_rowids_sql_binding_styles` passed. Both web-query variants returned
the same logged counts, although the WDL does not assert the expected counts.
See `run/console.log`, `run/workflow.log`, and `run/call-*/` for details.
Download task logs are under `downloaders/`.

`run/inventory.tsv` records lstat logical sizes and link targets without
following symlinks. To keep the inventory concise, it omits individual files
in the source/build checkout. `host/scratch-usage.txt` and
`host/filesystem-usage.txt` summarize usage after the workflow, rather than
at peak. At least 547 GiB was observed in use during the QNAME sort; the true
peak may have been higher between checks. Sort temporary files had already
been removed when this inventory was collected.

`metrics/cloudwatch-cpu-5min.json` contains host-wide CPUUtilization samples
in UTC, with five-minute aggregation. `metrics/sar-*.txt` contains host-wide
sysstat exports, typically sampled every ten minutes, including CPU, per-core
CPU, memory, and disk. `metrics/sysstat-sa01.bin` is the raw sysstat record
with only its embedded hostname replaced by an equal-length placeholder;
the redacted file was verified readable with `sar`. These coarse measurements can miss
short spikes. The sysstat record also covers time after workflow completion.

The host's network inventory and SSH host key-generation details were removed
from the cloud-init output. Hostnames, instance/resource identifiers, and
Docker Swarm node identifiers were redacted where found; public source and
input URLs and image digests were retained as provenance. Logs were otherwise
retained as collected. No databases, source checkout, credentials, Terraform
state, or private keys are included.
